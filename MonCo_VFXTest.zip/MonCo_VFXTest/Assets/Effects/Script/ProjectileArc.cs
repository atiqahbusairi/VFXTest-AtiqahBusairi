
using UnityEngine;

public class ProjectileArc : MonoBehaviour
{
    public Transform startPoint;
    public Transform endPoint;

    [Header("Arc Settings")]
    public float height = 3f;
    public float sideOffset = 2f;
    public float duration = 1f;

    [Header("Orbit Settings")]
    public float minOrbitRadius = 0.2f;
    public float maxOrbitRadius = 0.3f;
    public float orbitAngle = 200f;
    public float minOrbitDuration = 0.1f;
    public float maxOrbitDuration = 0.3f;

    [Header("Speed Control (Randomized)")]
    public float minSpeedMultiplier = 1.5f;
    public float maxSpeedMultiplier = 3f;
    private float actualSpeedMultiplier;

    [Header("Trail Settings")]
    public ParticleSystem trailEffect;
    private TrailRenderer[] trailVariants;

    [Header("Hit Effect")]
    public GameObject splashEffectPrefab;

    [HideInInspector] public float spiralDuration;

    private Vector3 orbitAxis;
    private float orbitRadius;
    private float orbitDuration;
    private float timeElapsed;
    private bool arcPhaseStarted = false;

    private Vector3 orbitEndPoint;
    private Vector3 p0, p1, p2;
    private float arcTime;

    private bool splashSpawned = false;

    void Start()
    {
        if (startPoint == null || endPoint == null)
        {
            Debug.LogError("ProjectileArc: Missing start or end point!");
            return;
        }

        // Randomize speed for this projectile
        actualSpeedMultiplier = Random.Range(minSpeedMultiplier, maxSpeedMultiplier);

        // Orbit randomization (with speed scaling)
        orbitRadius = Random.Range(minOrbitRadius, maxOrbitRadius);
        orbitDuration = Random.Range(minOrbitDuration, maxOrbitDuration) / actualSpeedMultiplier;
        spiralDuration = orbitDuration;
        orbitAxis = Random.onUnitSphere;

        // Arc bending (random up/down & sideways)
        height = Random.Range(-Mathf.Abs(height), Mathf.Abs(height));
        sideOffset = Random.Range(-Mathf.Abs(sideOffset), Mathf.Abs(sideOffset));

        // Pick a random TrailRenderer variant
        trailVariants = GetComponentsInChildren<TrailRenderer>(true);
        if (trailVariants.Length > 0)
        {
            foreach (var tr in trailVariants) tr.enabled = false;
            int randomIndex = Random.Range(0, trailVariants.Length);
            trailVariants[randomIndex].enabled = true;
        }

        if (trailEffect != null)
            trailEffect.Play();
    }

    void Update()
    {
        if (startPoint == null || endPoint == null) return;

        if (!arcPhaseStarted)
        {
            // Spiral phase (speed adjusted)
            timeElapsed += Time.deltaTime;
            float orbitProgress = Mathf.Clamp01(timeElapsed / orbitDuration);

            float angle = orbitProgress * orbitAngle;
            Quaternion rotation = Quaternion.AngleAxis(angle, orbitAxis);
            Vector3 offset = rotation * Vector3.forward * orbitRadius;

            transform.position = startPoint.position + offset;

            Vector3 tangentDir = Vector3.Cross(orbitAxis, offset).normalized;
            if (Vector3.Dot(tangentDir, (endPoint.position - transform.position)) < 0)
                tangentDir = -tangentDir;
            transform.rotation = Quaternion.LookRotation(tangentDir);

            if (orbitProgress >= 1f)
            {
                arcPhaseStarted = true;
                arcTime = 0f;

                orbitEndPoint = transform.position;
                p0 = orbitEndPoint;
                p2 = endPoint.position;

                Vector3 midPoint = (p0 + p2) / 2f;
                Vector3 up = Vector3.up * height;

                Vector3 forward = (p2 - p0).normalized;
                Vector3 right = Vector3.Cross(Vector3.up, forward).normalized * sideOffset;

                p1 = midPoint + up + right;
            }
        }
        else
        {
            // Arc phase (speed adjusted)
            arcTime += Time.deltaTime;
            float t = Mathf.Clamp01(arcTime / (duration / actualSpeedMultiplier));

            Vector3 position = Mathf.Pow(1 - t, 2) * p0 +
                               2 * (1 - t) * t * p1 +
                               Mathf.Pow(t, 2) * p2;

            transform.position = position;

            Vector3 tangent = 2 * (1 - t) * (p1 - p0) + 2 * t * (p2 - p1);
            if (tangent != Vector3.zero)
                transform.rotation = Quaternion.LookRotation(tangent);

            if (t >= 1f && !splashSpawned)
            {
                splashSpawned = true;

                if (trailEffect != null) trailEffect.Stop();

                if (splashEffectPrefab != null)
                {
                    GameObject splash = Instantiate(splashEffectPrefab, endPoint.position, Quaternion.identity);
                    ParticleSystem ps = splash.GetComponent<ParticleSystem>();
                    if (ps != null)
                        Destroy(splash, ps.main.duration + ps.main.startLifetime.constantMax);
                    else
                        Destroy(splash, 2f);
                }

                Destroy(gameObject, 0.5f);
            }
        }
    }
}
