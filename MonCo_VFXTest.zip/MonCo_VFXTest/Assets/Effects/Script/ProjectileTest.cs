using UnityEngine;
using System.Collections;

public class ProjectileTest : MonoBehaviour
{
    public GameObject projectilePrefab;
    public Transform startPoint;
    public Transform endPoint;

    [Header("Burst Settings")]
    public int minBurstCount = 2;          // Minimum trails
    public int maxBurstCount = 5;          // Maximum trails
    public float spawnIntervalMin = 0.05f; // Minimum delay between trails
    public float spawnIntervalMax = 0.2f;  // Maximum delay between trails

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Space))
        {
            int burstCount = UnityEngine.Random.Range(minBurstCount, maxBurstCount + 1);
            StartCoroutine(SpawnBurst(burstCount));
        }
    }

    IEnumerator SpawnBurst(int count)
    {
        for (int i = 0; i < count; i++)
        {
            SpawnProjectile();

            // Wait a random time before spawning the next projectile
            float delay = UnityEngine.Random.Range(spawnIntervalMin, spawnIntervalMax);
            yield return new WaitForSeconds(delay);
        }
    }

    void SpawnProjectile()
    {
        GameObject proj = Instantiate(projectilePrefab, startPoint.position, Quaternion.identity);
        ProjectileArc arc = proj.GetComponent<ProjectileArc>();
        arc.startPoint = startPoint;
        arc.endPoint = endPoint;

        // Randomize arc paths (some up, some down, some sideways)
        arc.height = UnityEngine.Random.Range(-3f, 5f);      // can arc downward (-) or upward (+)
        arc.sideOffset = UnityEngine.Random.Range(-4f, 4f);  // can curve left/right
    }
}
