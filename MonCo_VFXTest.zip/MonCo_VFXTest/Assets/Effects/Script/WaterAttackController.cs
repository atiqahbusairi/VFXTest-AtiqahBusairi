using UnityEngine;
using System.Collections;


public class WaterAttackController : MonoBehaviour
{
    [Header("Effect References")]
    public GameObject waterBallEffect;
    public GameObject projectilePrefab;
    public GameObject splashEffectPrefab;  // <--- Add this (controller will pass it to projectile)

    [Header("Points")]
    public Transform startPoint;
    public Transform endPoint;

    [Header("Timing")]
    public float waterBallDuration = 1.2f;
    public float projectileLeadTime = 0.5f;

    [Header("Projectile Burst Settings")]
    public int minBurstCount = 2;
    public int maxBurstCount = 5;
    public float spawnIntervalMin = 0.05f;
    public float spawnIntervalMax = 0.2f;

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Space))
        {
            StartCoroutine(PlayWaterAttack());
        }
    }

    IEnumerator PlayWaterAttack()
    {
        GameObject waterBall = null;

        // Step 1: Spawn waterball
        if (waterBallEffect != null)
        {
            waterBall = Instantiate(waterBallEffect, startPoint.position, Quaternion.identity);
        }

        // Step 2: Fire projectiles slightly before waterball disappears
        yield return new WaitForSeconds(waterBallDuration - projectileLeadTime);

        int burstCount = Random.Range(minBurstCount, maxBurstCount + 1);
        for (int i = 0; i < burstCount; i++)
        {
            SpawnProjectile();

            float delay = Random.Range(spawnIntervalMin, spawnIntervalMax);
            yield return new WaitForSeconds(delay);
        }

        // Step 3: Destroy waterball at end
        yield return new WaitForSeconds(projectileLeadTime);
        if (waterBall != null) Destroy(waterBall);
    }

    void SpawnProjectile()
    {
        GameObject proj = Instantiate(projectilePrefab, startPoint.position, Quaternion.identity);
        ProjectileArc arc = proj.GetComponent<ProjectileArc>();
        arc.startPoint = startPoint;
        arc.endPoint = endPoint;

        // Pass splash prefab so each projectile can spawn its own impact effect
        arc.splashEffectPrefab = splashEffectPrefab;
    }
}
