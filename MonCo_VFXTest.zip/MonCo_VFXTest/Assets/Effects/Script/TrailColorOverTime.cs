using UnityEngine;

[RequireComponent(typeof(TrailRenderer))]
public class TrailColorLifetime : MonoBehaviour
{
    public Gradient colorOverLifetime;

    private TrailRenderer trail;
    private float lifeTime;
    private float spawnTime;

    void Start()
    {
        trail = GetComponent<TrailRenderer>();

        // Estimate projectile life: combine orbit + arc phase duration
        ProjectileArc arc = GetComponent<ProjectileArc>();
        if (arc != null)
        {
            lifeTime = arc.spiralDuration + (arc.duration / arc.GetComponent<ProjectileArc>().minSpeedMultiplier);
        }
        else
        {
            lifeTime = trail.time; // fallback, use trail's time if no arc
        }

        spawnTime = Time.time;
    }

    void Update()
    {
        float elapsed = Time.time - spawnTime;
        float t = Mathf.Clamp01(elapsed / lifeTime);
        Color c = colorOverLifetime.Evaluate(t);

        // Make sure the material supports tint
        if (trail.material.HasProperty("_Color"))
            trail.material.SetColor("_Color", c);
        else if (trail.material.HasProperty("_BaseColor"))
            trail.material.SetColor("_BaseColor", c);
    }
}
